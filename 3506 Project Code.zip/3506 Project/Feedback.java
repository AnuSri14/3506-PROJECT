package easy.tuto.myquizapplication; 
import androidx.appcompat.app.AppCompatActivity; 
import android.content.Intent; 
import android.os.Bundle; 
import android.view.View; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.Toast; 
public class feedback extends AppCompatActivity { 
EditText name,email,problem; 
Button submit; 
@Override 
protected void onCreate(Bundle savedInstanceState) { 
super.onCreate(savedInstanceState); 
setContentView(R.layout.activity_feedback); 
name = findViewById(R.id.name); 
email = findViewById(R.id.email); 
problem = findViewById(R.id.problem); 
submit = findViewById(R.id.submit); 
submit.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
if(name.getText().toString().isEmpty() 
problem.getText().toString().isEmpty()){ 
|| 
email.getText().toString().isEmpty() 
|| 
Toast.makeText(feedback.this,"please fill all the details",Toast.LENGTH_SHORT).show(); 
}else { 
Intent i = new Intent(Intent.ACTION_SEND); 
i.setType("message/html"); 
i.putExtra(Intent.EXTRA_EMAIL, new String[]{"ushasri.boyina@gmail.com"}); 
i.putExtra(Intent.EXTRA_SUBJECT, "Feedback From Quiz App"); 
i.putExtra(Intent.EXTRA_TEXT, "Name: " + name.getText() + "\n Message:" + 
problem.getText()); 
try { 
startActivity(Intent.createChooser(i, "please select Email")); 
} catch (android.content.ActivityNotFoundException ex) { 
Toast.makeText(feedback.this, 
"There are or Email clients",
Toast.LENGTH_SHORT).show(); 
} 
} 
} 
}); 
} 
}