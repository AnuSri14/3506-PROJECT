package easy.tuto.myquizapplication; 
import androidx.annotation.NonNull; 
import androidx.appcompat.app.AlertDialog; 
import androidx.appcompat.app.AppCompatActivity; 
import android.content.DialogInterface; 
import android.content.Intent; 
import android.os.Bundle; 
import android.view.Menu; 
import android.view.MenuInflater; 
import android.view.MenuItem; 
import android.view.View; 
import android.widget.Button; 
import android.widget.Toast; 
import com.google.firebase.auth.FirebaseAuth; 
public class Categories extends AppCompatActivity { 
@Override 
protected void onCreate(Bundle savedInstanceState) { 
super.onCreate(savedInstanceState); 
setContentView(R.layout.activity_categories); 
Button verbal = findViewById(R.id.verbal); 
Button numerical = findViewById(R.id.numberical); 
Button reasoning = findViewById(R.id.reasoning); 
verbal.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
Intent intent = new Intent(Categories.this,MainActivity.class); 
startActivity(intent); 
} 
}); 
numerical.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
Intent intent = new Intent(Categories.this,Numerical.class); 
startActivity(intent);  
} 
}); 
reasoning.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
Intent intent = new Intent(Categories.this,Reasoning.class); 
startActivity(intent); 
} 
}); 
} 
@Override 
public void onBackPressed(){ 
new AlertDialog.Builder(this) 
.setTitle("Really Exit") 
.setMessage("Are you sure you want to exit?") 
.setNegativeButton(android.R.string.no, null) 
.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() { 
public void onClick(DialogInterface arg0, int arg1) { 
Categories.super.onBackPressed(); 
} 
}).create().show(); 
} 
@Override 
public boolean onCreateOptionsMenu(Menu menu) { 
MenuInflater inflater = getMenuInflater(); 
inflater.inflate(R.menu.menu,menu); 
return true; 
} 
@Override 
public boolean onOptionsItemSelected(@NonNull MenuItem item) { 
switch (item.getItemId()){ 
case R.id.feedback: 
Intent i = new Intent(Categories.this,feedback.class); 
startActivity(i); 
return  true; 
case R.id.logout: 
FirebaseAuth.getInstance().signOut(); 
Intent it = new Intent(Categories.this,login.class); 
startActivity(it); 
return true; 
} 
return super.onOptionsItemSelected(item); 
} 
} 