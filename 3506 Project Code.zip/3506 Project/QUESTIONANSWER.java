package easy.tuto.myquizapplication; 
public class QuestionAnswer { 
public static String question[] ={  
"Choose one of the following options that means the opposite of the given word; 
Copious:", 
"Which one is not the programming language?", 
"Where you are watching this video?" 
}; 
public static String choices[][] = { 
{"Reverse","Scarce","Abundant","Short"}, 
{"Java","Kotlin","Notepad","Python"}, 
{"Facebook","Whatsapp","Instagram","Youtube"} 
34 
}; 
public static String correctAnswers[] = { 
"Scarce", 
"Notepad", 
"Youtube" 
};