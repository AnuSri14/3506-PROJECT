package easy.tuto.myquizapplication; 
import androidx.annotation.NonNull; 
import androidx.appcompat.app.AppCompatActivity; 
import android.content.Intent; 
import android.os.Bundle; 
import android.view.View; 
import android.view.Window; 
import android.view.WindowManager; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.ProgressBar; 
import android.widget.TextView; 
import android.widget.Toast; 
import com.google.android.gms.tasks.OnCompleteListener; 
import com.google.android.gms.tasks.Task; 
import com.google.firebase.auth.AuthResult; 
import com.google.firebase.auth.FirebaseAuth; 
import com.google.firebase.auth.FirebaseUser; 
public class login extends AppCompatActivity { 
EditText emailEdit,passwordEdit; 
Button login; 
TextView register; 
FirebaseAuth mAuth; 
ProgressBar progressBar; 
@Override 
public void onStart() { 
super.onStart(); 
// Check if user is signed in (non-null) and update UI accordingly. 
FirebaseUser currentUser = mAuth.getCurrentUser(); 
if(currentUser != null){ 
Intent intent = new Intent(login.this, Categories.class); 
startActivity(intent); 
finish(); 
} 
} 
@Override 
protected void onCreate(Bundle savedInstanceState) { 
super.onCreate(savedInstanceState); 
requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title 
getSupportActionBar().hide(); // hide the title bar 
this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen 
setContentView(R.layout.activity_login); 
mAuth = FirebaseAuth.getInstance(); 
emailEdit = findViewById(R.id.txtEmail); 
passwordEdit = findViewById(R.id.txtPwd); 
progressBar = findViewById(R.id.progressBar); 
login = findViewById(R.id.btnLogin); 
register = findViewById(R.id.lnkRegister); 
login.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
String email = emailEdit.getText().toString(); 
String password = passwordEdit.getText().toString(); 
if( email.length() == 0 && password.length() == 0 ){ 
Toast.makeText(login.this, 
"please 
password.",Toast.LENGTH_SHORT).show(); 
} 
else { 
progressBar.setVisibility(view.VISIBLE); 
enter 
mAuth.signInWithEmailAndPassword(email, password) 
.addOnCompleteListener(new OnCompleteListener<AuthResult>() { 
@Override 
public void onComplete(@NonNull Task<AuthResult> task) { 
progressBar.setVisibility(view.GONE); 
if (task.isSuccessful()) { 
// Sign in success, update UI with the signed-in user's information 
email 
and 
Toast.makeText(login.this, "Authentication sucessful.", Toast.LENGTH_SHORT).show(); 
Intent intent = new Intent(login.this, Categories.class); 
startActivity(intent); 
finish(); 
} else { 
// If sign in fails, display a message to the user. 
Toast.makeText(login.this, "Authentication failed.", Toast.LENGTH_SHORT).show(); 
} 
} 
}); 
} 
}
}); 
register.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
Intent intent = new Intent(login.this, register.class); 
startActivity(intent); 
} 
}); 
} 
}