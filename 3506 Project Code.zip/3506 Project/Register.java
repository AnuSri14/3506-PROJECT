package easy.tuto.myquizapplication; 
import androidx.annotation.NonNull; 
import androidx.appcompat.app.AppCompatActivity; 
import android.content.Intent; 
import android.content.SharedPreferences; 
import android.os.Bundle; 
import android.view.View; 
import android.view.Window; 
import android.view.WindowManager; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.ProgressBar; 
import android.widget.TextView; 
import android.widget.Toast; 
import com.google.android.gms.tasks.OnCompleteListener; 
import com.google.android.gms.tasks.Task; 
import com.google.firebase.auth.AuthResult; 
import com.google.firebase.auth.FirebaseAuth; 
import com.google.firebase.auth.FirebaseUser; 
public class register extends AppCompatActivity { 
EditText name,emailEdit,passwordEdit; 
FirebaseAuth mAuth; 
ProgressBar progressBar; 
@Override 
public void onStart() { 
super.onStart(); 
// Check if user is signed in (non-null) and update UI accordingly. 
FirebaseUser currentUser = mAuth.getCurrentUser(); 
if(currentUser != null){ 
Intent intent = new Intent(register.this, Categories.class); 
startActivity(intent); 
finish(); 
} 
} 
@Override 
protected void onCreate(Bundle savedInstanceState) { 
super.onCreate(savedInstanceState); 
requestWindowFeature(Window.FEATURE_NO_TITLE); 
getSupportActionBar().hide(); 
// 
hide 
//will 
the 
hide 
title 
the 
this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen 
setContentView(R.layout.activity_register); 
mAuth = FirebaseAuth.getInstance(); 
name = findViewById(R.id.txtName); 
emailEdit = findViewById(R.id.txtEmail); 
passwordEdit = findViewById(R.id.txtPwd); 
progressBar = findViewById(R.id.progessBar); 
Button register = findViewById(R.id.btnRegister); 
TextView login = findViewById(R.id.lnkLogin); 
register.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View view) { 
String email = emailEdit.getText().toString(); 
String password = passwordEdit.getText().toString(); 
if( email.length() == 0) { 
Toast.makeText(register.this,"fill the name", Toast.LENGTH_SHORT).show(); 
return; 
title  
bar       
} 
if (password.length()==0) { 
Toast.makeText(register.this, "fill all the email", Toast.LENGTH_SHORT).show(); 
return; 
} 
progressBar.setVisibility(view.VISIBLE); 
mAuth.createUserWithEmailAndPassword(email, password) 
.addOnCompleteListener(new OnCompleteListener<AuthResult>() { 
@Override 
public void onComplete(@NonNull Task<AuthResult> task) { 
progressBar.setVisibility(view.GONE); 
if (task.isSuccessful()) { 
// Sign in success, update UI with the signed-in user's information 
Toast.makeText(register.this, "Authentication sucessful.", Toast.LENGTH_SHORT).show(); 
} else { 
// If sign in fails, display a message to the user. 
Toast.makeText(register.this, "Authentication failed.", Toast.LENGTH_SHORT).show(); 
} 
} 
}); 
} 
}); 
login.setOnClickListener(new View.OnClickListener() { 
@Override 
public void onClick(View v) { 
Intent intent = new Intent(register.this, login.class); 
startActivity(intent); 
} 
}); 
} 
} 